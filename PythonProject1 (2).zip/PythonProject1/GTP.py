import RPSG
import NGG
import TTT
import logging

logger= logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(message)s')

file_handler = logging.FileHandler('result.log')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

while True:
  logger.info("Choose The Game You Want To Play: ")
  logger.info("\n1: Rock Paper Scissors \n2: Number Guess Game\n3: Tic Tac Toe \n4: Exit")
 
  ch = int(input())
  if ch == 4:
        logger.info("Have a nice day!")
        break
  elif ch == 1:
        RPSG.game()
  elif ch == 2:
        NGG.game()
  elif ch == 3:
        TTT.game()
    
  a=input("Do you want to choose a game again Y/N:")
  a=a.lower()
  if a !='y': 
   logger.info("Have a nice day!")
   break