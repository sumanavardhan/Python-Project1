import logging

logger= logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(message)s')

file_handler = logging.FileHandler('result1.log')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

import random
def game():
    t=0
    cw=0
    uw=0

    while True:
        u = input("Enter a choice (rock, paper, scissors): ")
        u = u.lower()
        p = ["rock", "paper", "scissors"]
        c = random.choice(p)
        logger.info(f"You chose {u}, computer chose {c}.")

        if u == c:
            logger.info(f"Both players selected {u}. It's a tie!")
            t += 1
        elif u == "rock":
            if c == "scissors":
                logger.info("Rock smashes scissors! You win!")
                uw += 1
            else:
                logger.info("Paper covers rock! You lose.")
                cw +=1
        elif u == "paper":
            if c == "rock":
                logger.info("Paper covers rock! You win!")
                uw += 1
            else:
                logger.info("Scissors cuts paper! You lose.")
                cw += 1
        elif u == "scissors":
            if c == "paper":
                logger.info("Scissors cuts paper!\n You win!\nCongratulations!!")
                uw += 1
            else:
                logger.info("Rock smashes scissors! You lose.")
                cw += 1
        play_again = input("Play Rock Paper Scissors again? (y/n): ")
        if play_again.lower() != "y":
            break
    logger.info(f"\nYou Won:{uw}")
    logger.info(f"\nComputer Won:{cw}")
    logger.info(f"\nIt's a tie:{t}")

if __name__ == "__main__": game()