import logging

logger= logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(message)s')

file_handler = logging.FileHandler('result2.log')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

import random
def game():
    n= random.randint(0, 100+1)
    g = int(float(input("Enter a number from 0 to 100: ")))
    while True:
        if g==n: 
            logger.info (f"Your guess {g} is right !\n Congratulations!!")
        elif g < n:
            logger.info (f"Your guess {g} is low")
            g = int(float(input("Enter a number from 1 to 100: ")))
            continue
        elif g > n:
            logger.info (f"Your guess {g} is high")
            g = int(float(input("Enter a number from 1 to 100: ")))
            continue

        play_again = input("Play Number Guessing again? (y/n): ")
        if play_again.lower() != "y":
            break
        else:
            g = int(float(input("Enter a number from 0 to 100: ")))
        n= random.randint(0, 100+1)
        g = int(float(input("Enter a number from 0 to 100: ")))
        while True:
            if g==n: 
                logger.info (f"Your guess {g} is right !\n Congratulations!!")
            elif g < n:
                logger.info (f"Your guess {g} is low")
                g = int(float(input("Enter a number from 1 to 100: ")))
                continue
            elif g > n:
                logger.info (f"Your guess {g} is high")
                g = int(float(input("Enter a number from 1 to 100: ")))
                continue

            play_again = input("Play Number Guessing again? (y/n): ")
            if play_again.lower() != "y":
                break
            else:
                g = int(float(input("Enter a number from 0 to 100: ")))
if __name__ == "__main__": game()