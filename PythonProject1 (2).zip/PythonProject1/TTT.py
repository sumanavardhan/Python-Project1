
import logging

logger= logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter('%(levelname)s:%(name)s:%(message)s')

file_handler = logging.FileHandler('result3.log')

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

import random

Board = {'1': ' ' , '2': ' ' , '3': ' ' ,
         '4': ' ' , '5': ' ' , '6': ' ' ,
         '7': ' ' , '8': ' ' , '9': ' ' }

board_keys = []

for key in Board:
    board_keys.append(key)

def printBoard(board):
    logger.info(board['1'] + '|' + board['2'] + '|' + board['3'])
    logger.info('-+-+-')
    logger.info(board['4'] + '|' + board['5'] + '|' + board['6'])
    logger.info('-+-+-')
    logger.info(board['7'] + '|' + board['8'] + '|' + board['9'])

def game():

    turn = 'X'
    count = 0

    for i in range(10):
         printBoard(Board)
         logger.info("\nIt's your turn," + turn + ".Move to which place?")

         move = input("Choose Empty Place From (1 to 9):")        

         if Board[move] == ' ':
            Board[move] = turn
            count += 1
         else:
            logger.info("That place is already filled.\nMove to which place?")
            continue
        
         if count == 9:
            logger.info("\nGame Over.\n")  
            printBoard(Board)              
            logger.info("It's a Tie!!")
            break

         if count >= 5:
            if Board['1'] == Board['2'] == Board['3'] != ' ':
                printBoard(Board)
                logger.info("\nGame Over.\n")                
                logger.info(" Congratulations!! " +turn + " won. ")                
                break
            elif Board['4'] == Board['5'] == Board['6'] != ' ': 
                printBoard(Board)
                logger.info("\nGame Over.\n")                
                logger.info("Congratulations!! " +turn + " won. ")
                break
            elif Board['7'] == Board['8'] == Board['9'] != ' ':
                printBoard(Board)
                logger.info("\nGame Over.\n")                
                logger.info("Congratulation!! " +turn + " won. ")
                break
            elif Board['7'] == Board['4'] == Board['1'] != ' ': 
                printBoard(Board)
                logger.info("\nGame Over.\n")                
                logger.info("Congratulations!! " +turn + " won.")
                break
            elif Board['8'] == Board['5'] == Board['2'] != ' ': 
                printBoard(Board)
                logger.info("\nGame Over.\n")                
                logger.info("Congratulations!! " +turn + " won.")
                break
            elif Board['9'] == Board['6'] == Board['3'] != ' ': 
                printBoard(Board)
                logger.info("\nGame Over.\n")                
                logger.info("Congratulations!! " +turn + " won.")
                break 
            elif Board['3'] == Board['5'] == Board['7'] != ' ': 
                printBoard(Board)
                logger.info("\nGame Over.\n")                
                logger.info("Congratulations!! " +turn + " won.")
                break
            elif Board['9'] == Board['5'] == Board['1'] != ' ': 
                printBoard(Board)
                logger.info("\nGame Over.\n")                
                logger.info("Congratulations!! " +turn + " won.")
                break 

         if turn =='X':
            turn = 'O'
         else:
            turn = 'X'        
    
    restart = input("Do want to play Again?(y/n):\n")
    if restart == "y" or restart == "Y":  
        for key in board_keys:
            Board[key] = " "

        game()

if __name__ == "__main__":
   game()